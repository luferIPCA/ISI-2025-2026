﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using AuthRest.Entities;
using AuthRest.Services;

namespace AuthRest.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class Calculus : ControllerBase
    {

    }
}
