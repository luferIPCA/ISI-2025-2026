
Installation:
---------------

1- Download Node.js
	https://nodejs.org/en/
	- instalar
	- testar:
		- node --version && npm --version

2- Instalar Node-Red
	https://nodered.org/docs/getting-started/windows#running-on-windows
	- c:\npm install -g --unsafe-perm node-red

3- Running
	- c:\node-red

4- Using
	http://127.0.0.1:1880/

5- Node-Red dashboard
https://flows.nodered.org/node/node-red-dashboard
https://stevesnoderedguide.com/node-red-dashboard
https://stevesnoderedguide.com/using-the-node-red-chart-node
https://www.youtube.com/watch?v=PwG56kuoo-o

-----------------

Mosquitto
---------------------
https://bytesofgigabytes.com/mqtt/windows-command-prompt-as-publisher-and-subscriber/

-------
start:
mosquitto_sub -t test -h localhost			(topic="test")


--------------------

Noe-Red: How-to

https://www.youtube.com/channel/UCQaB8NXBEPod7Ab8PPCLLAA
https://www.youtube.com/watch?v=3AR432bguOY

Node-Red Messages
https://nodered.org/docs/user-guide/messages


Node-Red Dashboards
http://localhost:1880/ui
