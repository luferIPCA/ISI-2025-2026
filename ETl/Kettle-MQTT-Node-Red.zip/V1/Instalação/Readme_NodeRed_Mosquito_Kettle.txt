
Installation:
---------------

https://nodered.org/docs/getting-started/windows#running-on-windows

1- Node.js
https://nodejs.org/en/

	- testar:
	- node --version && npm --version

2- Node-Red
	- c:\npm install -g --unsafe-perm node-red

3- Running
	- c:\node-red

4- Using
	http://127.0.0.1:1880/

5- Node-Red dashboard
https://flows.nodered.org/node/node-red-dashboard
https://stevesnoderedguide.com/node-red-dashboard
https://stevesnoderedguide.com/using-the-node-red-chart-node
https://www.youtube.com/watch?v=PwG56kuoo-o

6 - Node-Red Messages

https://nodered.org/docs/user-guide/messages


7 - See Dashboards
http://localhost:1880/ui

-----------------

How-to

https://www.youtube.com/channel/UCQaB8NXBEPod7Ab8PPCLLAA
https://www.youtube.com/watch?v=3AR432bguOY
https://www.youtube.com/watch?v=dKkRn3CM-ZI

---------------------
Mosquitto
---------------------

start:
(server por defeito)
mosquitto -v
(mostra os send e os receive)

(server atento a tópicos)
mosquitto_sub -t test -h localhost			(topic="test")

(cliente gerando topicos)
mosquitto_pub -t test -h localhost -m "Temperatura :10"


Node-Red com Mosquitto
-----------------------
https://cedalo.com/blog/node-red-and-mqtt-broker-guide/

MQTT in Node RED: Building a Dashboard and Logging Data
-------------------------------------------------------
https://www.youtube.com/watch?v=TNHAZxwB-9o

------------
Pentaho PDI
------------
copiar o componente "pentaho-mqtt" para a pasta "plugins" do pdi