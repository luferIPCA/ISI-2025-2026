

 
 * Kettle
 * MSC.ESE 
 * by lufer - IPCA


	Parsing Data
	Spliting Text files
	Add constants
	Javascript
	XPath
